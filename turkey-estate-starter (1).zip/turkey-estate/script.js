/* Turkey Estate: static demonstrator. All properties and prices are fictional. */
const photos = {
  a:'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=950&q=82',
  b:'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=950&q=82',
  c:'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=950&q=82',
  d:'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=950&q=82',
  e:'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=950&q=82',
  f:'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=950&q=82',
  g:'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=950&q=82',
  h:'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=950&q=82',
  i:'https://images.unsplash.com/photo-1600585152915-d208bec867a1?w=950&q=82',
  j:'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=950&q=82',
  k:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=950&q=82',
  l:'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=950&q=82'
};
const properties = [
  {id:1,city:'Istanbul',district:'Бешикташ',title:'Светлая квартира с видом на Босфор',type:'Квартира',deal:'sale',price:325000,bedrooms:2,bathrooms:2,area:110,img:photos.a,description:'Современная квартира с просторной гостиной и большими окнами. Удобное расположение рядом с прогулочными маршрутами и городскими кафе.'},
  {id:2,city:'Antalya',district:'Коньяалты',title:'Апартаменты в пешей доступности от моря',type:'Квартира',deal:'rent',price:1250,bedrooms:2,bathrooms:1,area:88,img:photos.b,description:'Уютные апартаменты со светлой отделкой и открытой планировкой. Подходят для длительного проживания.'},
  {id:3,city:'Bodrum',district:'Ялыкавак',title:'Современная вилла с приватным бассейном',type:'Вилла',deal:'sale',price:890000,bedrooms:4,bathrooms:3,area:240,img:photos.d,description:'Просторная вилла с террасой, несколькими спальнями и зоной для отдыха на открытом воздухе.'},
  {id:4,city:'Istanbul',district:'Кадыкёй',title:'Дизайнерская квартира в центре района',type:'Квартира',deal:'rent',price:1700,bedrooms:1,bathrooms:1,area:74,img:photos.c,description:'Стильная квартира с акцентами из натуральных материалов. Рядом магазины, рестораны и общественный транспорт.'},
  {id:5,city:'Antalya',district:'Лара',title:'Пентхаус с террасой и панорамными окнами',type:'Пентхаус',deal:'sale',price:410000,bedrooms:3,bathrooms:2,area:167,img:photos.f,description:'Пентхаус с просторной террасой, высоким уровнем естественного освещения и удобной планировкой.'},
  {id:6,city:'Bodrum',district:'Гюмюшлюк',title:'Тихая вилла для отдыха у Эгейского моря',type:'Вилла',deal:'rent',price:3900,bedrooms:3,bathrooms:2,area:185,img:photos.e,description:'Место для спокойного отдыха: отдельная гостиная, открытая терраса и достаточно пространства для семьи.'},
  {id:7,city:'Istanbul',district:'Нишанташи',title:'Премиальная квартира с высокими потолками',type:'Квартира',deal:'sale',price:520000,bedrooms:3,bathrooms:2,area:145,img:photos.g,description:'Городские апартаменты с выразительным интерьером и просторной обеденной зоной.'},
  {id:8,city:'Antalya',district:'Алтынташ',title:'Новая квартира в современном комплексе',type:'Квартира',deal:'rent',price:950,bedrooms:1,bathrooms:1,area:63,img:photos.h,description:'Компактная квартира для комфортной жизни с функциональной кухней и уютной гостиной.'},
  {id:9,city:'Bodrum',district:'Тюркбюкю',title:'Семейная вилла с просторной террасой',type:'Вилла',deal:'sale',price:740000,bedrooms:4,bathrooms:3,area:220,img:photos.i,description:'Вилла с несколькими зонами для отдыха и просторной планировкой для большой семьи.'},
  {id:10,city:'Istanbul',district:'Сарыер',title:'Апартаменты в зелёном районе',type:'Квартира',deal:'rent',price:2100,bedrooms:3,bathrooms:2,area:135,img:photos.j,description:'Комфортные апартаменты для тех, кто ценит пространство, свет и спокойный ритм города.'},
  {id:11,city:'Antalya',district:'Коньяалты',title:'Стильная квартира с большой гостиной',type:'Квартира',deal:'sale',price:219000,bedrooms:2,bathrooms:1,area:105,img:photos.k,description:'Светлая квартира с лаконичным интерьером и удобным зонированием пространства.'},
  {id:12,city:'Bodrum',district:'Битез',title:'Уютные апартаменты рядом с набережной',type:'Квартира',deal:'rent',price:1450,bedrooms:2,bathrooms:1,area:92,img:photos.l,description:'Апартаменты с приятной атмосферой и комфортным пространством для проживания.'}
];
const cityRu = {Istanbul:'Стамбул',Antalya:'Анталья',Bodrum:'Бодрум'};
const state = {deal:'all',city:'all',type:'all',maxPrice:'',bedrooms:'all',sort:'featured',favoritesOnly:false};
const $ = id => document.getElementById(id);
const grid = $('properties-grid');
const euro = n => new Intl.NumberFormat('ru-RU',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(n);
const favKey = 'turkey-estate-favorites-v1';
let favorites;
try { const parsed = JSON.parse(localStorage.getItem(favKey)||'[]'); favorites = new Set(Array.isArray(parsed)?parsed.filter(Number.isInteger):[]); } catch { favorites = new Set(); }
let toastTimeout;
function notify(msg){ const el=$('toast'); el.textContent=msg;el.classList.add('visible');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>el.classList.remove('visible'),2600); }
function syncFav(){ $('fav-count').textContent=favorites.size;$('fav-count').classList.toggle('hidden',!favorites.size);$('favorites-header').setAttribute('aria-pressed',String(state.favoritesOnly)); }
function setFav(id){ if(favorites.has(id)) favorites.delete(id); else favorites.add(id); try{localStorage.setItem(favKey,JSON.stringify([...favorites]));}catch{notify('Не удалось сохранить избранное в браузере');}syncFav();render();notify(favorites.has(id)?'Добавлено в избранное':'Удалено из избранного'); }
function filtered(){
  let list=properties.filter(p=>(state.deal==='all'||p.deal===state.deal)&&(state.city==='all'||p.city===state.city)&&(state.type==='all'||p.type===state.type)&&(!state.maxPrice||p.price<=Number(state.maxPrice))&&(state.bedrooms==='all'||p.bedrooms>=Number(state.bedrooms))&&(!state.favoritesOnly||favorites.has(p.id)));
  if(state.sort==='price-asc')list.sort((a,b)=>a.price-b.price);
  if(state.sort==='price-desc')list.sort((a,b)=>b.price-a.price);
  if(state.sort==='area-desc')list.sort((a,b)=>b.area-a.area);
  return list;
}
function card(p){return `<article class="property-card" data-id="${p.id}" role="button" tabindex="0" aria-label="Подробнее: ${p.title}"><div class="property-image-wrap"><img src="${p.img}" alt="Иллюстративное фото: ${p.title}" loading="lazy" onerror="this.onerror=null;this.src='https://placehold.co/650x550/eeeae5/777777?text=Turkey+Estate'"/><span class="property-badge">${p.deal==='rent'?'Аренда · месяц':'Продажа'}</span><button type="button" class="heart-btn ${favorites.has(p.id)?'liked':''}" data-favorite="${p.id}" aria-label="${favorites.has(p.id)?'Убрать из избранного':'Добавить в избранное'}" aria-pressed="${favorites.has(p.id)}"><svg class="icon"><use href="#i-heart"/></svg></button></div><div class="card-body"><p class="card-location"><svg class="icon"><use href="#i-pin"/></svg>${cityRu[p.city]}, ${p.district}</p><h3 class="card-title">${p.title}</h3><div class="card-features"><span><svg class="icon"><use href="#i-bed"/></svg>${p.bedrooms} сп.</span><span><svg class="icon"><use href="#i-bath"/></svg>${p.bathrooms} ван.</span><span><svg class="icon"><use href="#i-area"/></svg>${p.area} м²</span></div><div class="card-bottom"><span class="card-price">${euro(p.price)}${p.deal==='rent'?'<small> / мес.</small>':''}</span><span class="card-link">Подробнее <svg class="icon small"><use href="#i-arrow"/></svg></span></div></div></article>`;}
function syncControls(){
 document.querySelectorAll('[data-deal]').forEach(b=>b.classList.toggle('selected',b.dataset.deal===state.deal));
 document.querySelectorAll('[data-chip]').forEach(b=>b.classList.toggle('active',b.dataset.chip===state.city));
 document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===state.deal&&!state.favoritesOnly));
 $('city-select').value=state.city;$('type-select').value=state.type;$('rooms-select').value=state.bedrooms;$('max-price').value=state.maxPrice;$('sort-select').value=state.sort;
 $('favorites-header').style.color=state.favoritesOnly?'#bf5942':'';
}
function render(){ const list=filtered();grid.innerHTML=list.map(card).join('');$('result-count').textContent=`${list.length} ${list.length===1?'объект':list.length>1&&list.length<5?'объекта':'объектов'}`;$('empty-state').classList.toggle('hidden',!!list.length);syncControls();syncFav(); }
function reset(){Object.assign(state,{deal:'all',city:'all',type:'all',maxPrice:'',bedrooms:'all',sort:'featured',favoritesOnly:false});render();}
function openProperty(id){const p=properties.find(x=>x.id===id);if(!p)return;const modal=$('property-modal');$('modal-body').innerHTML=`<img class="modal-photo" src="${p.img}" alt="Иллюстративное фото объекта" onerror="this.onerror=null;this.src='https://placehold.co/900x450/eeeae5/777777?text=Turkey+Estate'"/><div class="modal-content"><span class="modal-tag">ДЕМО-ОБЪЕКТ · ${p.deal==='rent'?'АРЕНДА':'ПРОДАЖА'}</span><h2 id="modal-title">${p.title}</h2><p class="card-location"><svg class="icon"><use href="#i-pin"/></svg>${cityRu[p.city]}, ${p.district}</p><div class="modal-facts"><span><svg class="icon"><use href="#i-bed"/></svg>${p.bedrooms} спальни</span><span><svg class="icon"><use href="#i-bath"/></svg>${p.bathrooms} ванные</span><span><svg class="icon"><use href="#i-area"/></svg>${p.area} м²</span><span>${p.type}</span></div><p>${p.description}</p><p class="modal-disclaimer">Все данные и изображения демонстрационные. Объект не размещён в реальной продаже или аренде.</p><div class="modal-footer"><span class="modal-price">${euro(p.price)} ${p.deal==='rent'?'<small>/ месяц</small>':''}</span><a class="modal-action" href="mailto:hello@example.com?subject=${encodeURIComponent('Демо-запрос Turkey Estate: объект '+p.id)}&body=${encodeURIComponent('Здравствуйте! Меня интересует объект: '+p.title+'.\nЭто демонстрационный запрос.')}" >Написать об объекте ↗</a></div></div>`;
modal.classList.remove('hidden');document.body.style.overflow='hidden';modal.querySelector('.modal-panel').focus();history.replaceState(null,'',`#property-${p.id}`);
}
function closeModal(){ $('property-modal').classList.add('hidden');document.body.style.overflow='';if(location.hash.startsWith('#property-'))history.replaceState(null,'','#catalog'); }
grid.addEventListener('click',e=>{const fav=e.target.closest('[data-favorite]');if(fav){e.stopPropagation();setFav(Number(fav.dataset.favorite));return;}const c=e.target.closest('[data-id]');if(c)openProperty(Number(c.dataset.id));});
grid.addEventListener('keydown',e=>{const c=e.target.closest('[data-id]');if(c&&(e.key==='Enter'||e.key===' ')){if(e.target.closest('button'))return;e.preventDefault();openProperty(Number(c.dataset.id));}});
$('search-form').addEventListener('submit',e=>{e.preventDefault();state.city=$('city-select').value;state.type=$('type-select').value;state.maxPrice=$('max-price').value;state.bedrooms=$('rooms-select').value;state.favoritesOnly=false;render();$('catalog').scrollIntoView({behavior:'smooth'});});
document.querySelectorAll('[data-deal]').forEach(b=>b.addEventListener('click',()=>{state.deal=b.dataset.deal;state.favoritesOnly=false;render();}));
document.querySelectorAll('[data-chip]').forEach(b=>b.addEventListener('click',()=>{state.city=b.dataset.chip;state.favoritesOnly=false;render();}));
document.querySelectorAll('[data-city]').forEach(b=>b.addEventListener('click',()=>{state.city=b.dataset.city;state.favoritesOnly=false;render();$('catalog').scrollIntoView({behavior:'smooth'});}));
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>{state.deal=b.dataset.nav;state.favoritesOnly=false;render();$('site-nav').classList.remove('open');$('menu-toggle').setAttribute('aria-expanded','false');}));
$('sort-select').addEventListener('change',e=>{state.sort=e.target.value;render();});
$('favorites-header').addEventListener('click',()=>{state.favoritesOnly=!state.favoritesOnly;render();$('catalog').scrollIntoView({behavior:'smooth'});});
$('reset-btn').addEventListener('click',reset);$('empty-reset').addEventListener('click',reset);
$('modal-close').addEventListener('click',closeModal);$('property-modal').addEventListener('click',e=>{if(e.target.dataset.closeModal)closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('property-modal').classList.contains('hidden'))closeModal();});
$('menu-toggle').addEventListener('click',()=>{const expanded=$('menu-toggle').getAttribute('aria-expanded')==='true';$('menu-toggle').setAttribute('aria-expanded',String(!expanded));$('site-nav').classList.toggle('open',!expanded);});
$('year').textContent=new Date().getFullYear();render();
if(/^#property-\d+$/.test(location.hash))openProperty(Number(location.hash.replace('#property-','')));
